let GAMELOOPJS_SPEED = 1000 / 60;
let GAMELOOPJS_SPACE_TIMEOUT = 100;
let GAMELOOPJS_INTERVALS = [];
let currentHighscore = 0;
let MAP_X = 0;
let GAME_OBSTACLES = [];
let gameOver = false;
const GAMELOOPJS_KEY = {};
let gameStarted = false;

function startGame() {
    // Titelseite ausblenden, wenn das Spiel gestartet wird
    document.getElementById('start-screen').style.display = 'none';
    
    // Setup: Spielfigur platzieren, Map generieren, Event-Listener aktivieren usw.
    gameStarted = true;
  }
  
  function showInstructions() {
    // Spielanleitungs-Overlay anzeigen
    document.getElementById("instructions-overlay").style.display = "flex";
  }
  
  function closeInstructions() {
    // Spielanleitung wieder ausblenden
    document.getElementById("instructions-overlay").style.display = "none";
  }
  
  window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('start-btn').addEventListener('click', startGame);
    document.getElementById('howto-button').addEventListener('click', showInstructions);
  });
  

document.addEventListener('keydown', e => GAMELOOPJS_KEY[e.keyCode] = true);
document.addEventListener('keyup', e => {
    GAMELOOPJS_KEY[e.keyCode] = false;
});

function addMap(src, parts = 10) {
    document.head.innerHTML += `
    <style>
      .moving-map {
        height: 100vh;
        position: absolute;
        left: 0;
        bottom: 100px;
        opacity: 0.75;
      }
    </style>`;

    for (let i = 0; i < parts; i++) {
        const map = document.createElement('img');
        map.src = src;
        map.id = 'map' + i;
        map.classList.add('moving-map');
        document.body.appendChild(map);

        map.onload = () => {
            setTimeout(() => {
                document.querySelectorAll('.moving-map').forEach((map, i) => {
                    map.style.left = (i * map.getBoundingClientRect().width) + 'px';
                    gameStarted = true;
                });
            }, 100);
        }
    }
}

function moveMap(speed = 1) {
    const interval = setInterval(() => {
        if(!gameStarted) return;
        document.querySelectorAll('.moving-map').forEach(part => {
            MAP_X = 0 - (part.getBoundingClientRect().x - speed);
            part.style.left = (part.getBoundingClientRect().x - speed) + 'px';
        });

        GAME_OBSTACLES.forEach(obstacle => {
            obstacle.style.left = (obstacle.getBoundingClientRect().x - speed) + 'px';
        });
    }, 1000 / 60);

    GAMELOOPJS_INTERVALS.push(interval);
}

function placeObstacle(src, x, y, width = 100, height = 100) {
    let obstacle = document.createElement('img');
    obstacle.src = src;
    obstacle.style.zIndex = 1;
    obstacle.style.position = 'absolute';
    obstacle.style.left = x + 'px';
    obstacle.style.top = y + 'px';
    obstacle.style.width = width + 'px';
    obstacle.style.height = height + 'px';
    obstacle.classList.add('game-obstacle');
    document.body.appendChild(obstacle);
    GAME_OBSTACLES.push(obstacle);
}

class GameObject {

    img;
    x;
    y;
    groundLevel;
    height;
    name;
    imgElement;
    zIndex = 2;
    animationInterval;

    constructor(img, x, y, height = 100, name) {
        this.img = img;
        this.x = x;
        this.y = y;
        this.groundLevel = y;
        this.height = height;
        this.name = name;
        this.spawn();
    }

    spawn() {
        this.imgElement = document.createElement('img');
        this.imgElement.src = this.img;
        this.imgElement.style.position = 'absolute';
        this.imgElement.style.left = this.x + 'px';
        this.imgElement.style.top = this.y + 'px';
        this.imgElement.style.height = this.height + 'px';
        this.imgElement.style.zIndex = this.zIndex;
        document.body.appendChild(this.imgElement);
    }    

    animate(first, last, animationSpeed = 100) {
        if (gameOver) return;
        let current = first;
        clearInterval(this.animationInterval);
        this.animationInterval = setInterval(() => {
            // Frame hochzählen
            current++;

            // Wenn Limit erreicht, wieder zurück auf first (z.B. 0)
            if (current > last) {
                current = first;
            }

            // Endung der Datei ermitteln
            const extensionMatch = this.img.match(/\.\w+$/);
            const extension = extensionMatch ? extensionMatch[0] : '';

            // Bildpfad anpassen, z.B. './img/sata/santa0.png' -> './img/sata/santa1.png'
            const basePath = this.img.replace(/\d+\.\w+$/, '');

            // src des Bildes aktualisieren
            this.imgElement.src = `${basePath}${current}${extension}`;
            this.imgElement.style.top = `${this.y}px`;
            this.imgElement.style.left = `${this.x}px`;


        }, animationSpeed);
        GAMELOOPJS_INTERVALS.push(this.animationInterval);
    }

    jump(maxHeight = 300, speed = 10) {
        if (this.isJumping) return; // Kein neuer Sprung, wenn bereits springend
        if (gameOver) return;

        this.isJumping = true;
        let direction = -1; // Nach oben
        let maxReached = false;
        
        this.animate(7, 7);

        this.jumpInterval = setInterval(() => {
            if (!maxReached) {
                this.y += direction * speed;
                if (this.y <= this.groundLevel - maxHeight) {
                    maxReached = true; // Maximum erreicht
                    direction = 1; // Nach unten
                }
            } else {
                // Fall zurück zum Boden
                this.y += direction * speed;
                if (this.y >= this.groundLevel) {
                    this.y = this.groundLevel; // Auf Boden zurücksetzen
                    this.endJump();
                }
            }
            this.imgElement.style.top = `${this.y}px`;
        }, 1000 / 60); // 60 FPS
    }

    cancelJump() {
        if (this.gameOver) return;
        if (this.isJumping) {
            clearInterval(this.jumpInterval);
            this.jumpInterval = null;
            this.isJumping = false;

            // Fall zurück zum Boden
            this.fallToGround()
        }
    }

    fallToGround(speed = 5) {
        const fallInterval = setInterval(() => {
            this.y += speed;
            if (this.y >= this.groundLevel) {
                this.y = this.groundLevel;
                clearInterval(fallInterval); // Stopp bei Boden
            }
            this.imgElement.style.top = `${this.y}px`;
        }, 1000 / 60);
    }

    endJump() {
        clearInterval(this.jumpInterval);
        this.jumpInterval = null;
        this.isJumping = false;
        this.animate(0, 6);
    }

    isColliding(object1, object2) {
        if (!object1 || !object2) return false; // Falls ein Objekt nicht existiert, gibt es keine Kollision
    
        const rect1 = object1.imgElement.getBoundingClientRect();
        const rect2 = object2.getBoundingClientRect();
    
        return (
            rect1.left < rect2.right &&
            rect1.right > rect2.left &&
            rect1.top < rect2.bottom &&
            rect1.bottom > rect2.top
        );
    } 

    lastProjectileTime = 0;
    
    throwProjectile(src, direction = 'right', speed = 10, arcHeight = 25) {
        if (gameOver) return;

        let now = Date.now();
        if (now - this.lastProjectileTime < 3000) return;

        this.lastProjectileTime = now;
        
        let projectile = document.createElement('img');
        projectile.src = src;
        projectile.style.position = 'absolute';
        projectile.style.left = `${this.x + (direction === 'right' ? 50 : -50)}px`;
        projectile.style.top = `${this.y + 20}px`;
        projectile.style.width = '30px';
        projectile.style.height = '30px';
        projectile.classList.add('projectile');
        document.body.appendChild(projectile);
    
        let vx = direction === 'right' ? speed : -speed * 0.4;  // Horizontale Geschwindigkeit
        let vy = -arcHeight;  // Anfangsgeschwindigkeit nach oben
        let gravity = 0.4; // Schwerkraft, die das Projektil nach unten zieht
        let time = 0; // Zeitzähler
    
        let interval = setInterval(() => {
            // Aktualisiere Position basierend auf Parabel-Formel
            let newX = parseInt(projectile.style.left) + vx;
            let newY = parseInt(projectile.style.top) + vy + (gravity * time);
    
            projectile.style.left = `${newX}px`;
            projectile.style.top = `${newY}px`;
    
            // Schwerkraft verstärkt mit der Zeit
            vy += gravity;
            time++;
    
            // Prüfe auf Kollision
            if (isColliding(projectile, chicken) && this !== chicken) { 
                hitCharacter(chicken);
                clearInterval(interval);
                projectile.remove();
            }
    
            if (isColliding(projectile, cat) && this !== cat) { 
                hitCharacter(cat);
                clearInterval(interval);
                projectile.remove();
            }
    
            // Wenn das Projektil aus dem Bildschirm fliegt, entferne es
            if (newX < 0 || newX > window.innerWidth || newY > window.innerHeight) {
                clearInterval(interval);
                projectile.remove();
            }
        }, 1000 / 60); // 60 FPS
    
        GAMELOOPJS_INTERVALS.push(interval);
    } 
    
    stopAnimation() {
        clearInterval(this.animationInterval);
    }         
}

function hitCharacter(character) {
    if (character.isImmune) return;
    
    character.isImmune = true;
    character.imgElement.style.opacity = '0.6'; // Transparenz für Immunität
    loseLife(character === chicken ? 'chicken' : 'cat'); // Leben abziehen

    setTimeout(() => {
        character.isImmune = false;
        character.imgElement.style.opacity = '1'; // Normalisieren
    }, 3000);
}

function flyUp(gameObject, speed = 10, repeat = 2000) {
    let i = 0;
    let interval = gameInterval(() => {
        gameObject.y -= speed;
        if (++i >= repeat) {
            clearInterval(interval);
        }
    }, GAMELOOPJS_SPEED);
}

function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function flyDown(gameObject, speed = 10, repeat = 2000) {
    let i = 0;
    let interval = gameInterval(() => {
        gameObject.y += speed;
        if (++i >= repeat) {
            clearInterval(interval);
        }
    }, GAMELOOPJS_SPEED);
}

GAMELOOPJS_START();
function GAMELOOPJS_START() {
    let spaceKeyLocked = false;
    gameInterval(() => {
        checkCollisionWithObstacles();
        if (GAMELOOPJS_KEY[37]) leftKeyPressed();
        if (GAMELOOPJS_KEY[39]) rightKeyPressed();
        if (GAMELOOPJS_KEY[38]) upKeyPressed();
        if (GAMELOOPJS_KEY[40]) downKeyPressed();
        if (GAMELOOPJS_KEY[65]) aKeyPressed(); // A-Taste (65 ist der Keycode für A)
        if (GAMELOOPJS_KEY[68]) dKeyPressed(); // D-Taste (68 ist der Keycode für D)
        if (GAMELOOPJS_KEY[87]) wKeyPressed(); // W-Taste (87 ist der Keycode für W)
        if (GAMELOOPJS_KEY[83]) sKeyPressed(); // S-Taste (83 ist der Keycode für S)
        
        if (GAMELOOPJS_KEY[80]) chicken.throwProjectile('./img/Granate/Ei.png', 'right');  // Chicken vorwärts (P)
        if (GAMELOOPJS_KEY[79]) chicken.throwProjectile('./img/Granate/Ei.png', 'left');   // Chicken rückwärts (O)
        
        if (GAMELOOPJS_KEY[71]) cat.throwProjectile('./img/Granate/Wollknäuel.png', 'right');  // Cat vorwärts (G)
        if (GAMELOOPJS_KEY[70]) cat.throwProjectile('./img/Granate/Wollknäuel.png', 'left');   // Cat rückwärts (F)
        
        if (GAMELOOPJS_KEY[32]) {
            if (!spaceKeyLocked) {
                spaceKeyPressed();
                spaceKeyLocked = true;
                setTimeout(() => {
                    spaceKeyLocked = false;
                }, GAMELOOPJS_SPACE_TIMEOUT);
            }
        }
    }, 100);
}

function waitForCollision(object1, object2) {
    return new Promise((resolve) => {
        let interval = gameInterval(() => {
            if (object2 instanceof Array) {
                object2.forEach((gameObject) => {
                    if (isColliding(object1, gameObject)) {
                        clearInterval(interval);  // Wichtig!
                        resolve([object1, gameObject]);
                    }
                });
            } else {
                if (isColliding(object1, object2)) {
                    clearInterval(interval);  // Wichtig!
                    resolve([object1, object2]);
                }
            }
        }, 50);
    });
}

function checkCollisionWithObstacles() {
    if (!chicken || !chicken.imgElement) return;
    if (!cat || !cat.imgElement) return;

    GAME_OBSTACLES.forEach(obstacle => {
        if (!chicken.isImmune && isColliding(chicken, obstacle)) {
            chicken.x -= 60;
            chicken.imgElement.style.left = chicken.x + 'px';
            loseLife('chicken');
            chicken.isImmune = true;
            chicken.imgElement.style.opacity = '0.6';

            setTimeout(() => {
                chicken.isImmune = false;
                chicken.imgElement.style.opacity = '1';
            }, 3000);
        }

        if (!cat.isImmune && isColliding(cat, obstacle)) {
            cat.x -= 60;
            cat.imgElement.style.left = cat.x + 'px';
            loseLife('cat');
            cat.isImmune = true;
            cat.imgElement.style.opacity = '0.6';

            setTimeout(() => {
                cat.isImmune = false;
                cat.imgElement.style.opacity = '1';
            }, 3000);
        }
    });
}

function isColliding(object1, object2) {
    if (!object1 || !object2) return false;
    
    const rect1 = object1.imgElement ? object1.imgElement.getBoundingClientRect() : object1.getBoundingClientRect();
    const rect2 = object2.imgElement ? object2.imgElement.getBoundingClientRect() : object2.getBoundingClientRect();

    return (
        rect1.left < rect2.right &&
        rect1.right > rect2.left &&
        rect1.top < rect2.bottom &&
        rect1.bottom > rect2.top
    );
}

function loseLife(player) {
    if (player === 'chicken') {
        chickenHP--;
    } else if (player === 'cat') {
        catHP--;
    }
    checkGameOver(); // <- HIER aufrufen!
}

function checkGameOver() {
    if (chickenHP <= 0) {
        endGame("cat", "chicken");
    } else if (catHP <= 0) {
        endGame("chicken", "cat");
    }
}

function getName(character) {
    return character?.toUpperCase(); // oder hol den Namen dynamisch aus einem Objekt
}

function showGameOverScreen(winnerText = "", loserText = "") {
    const gameOverImage = document.getElementById("gameOverImage");
    const screen = document.getElementById("gameOverScreen");
    const winnerMessage = document.getElementById('winnerMessage');
    const loserMessage = document.getElementById('loserMessage');

    if (!gameOverImage || !screen || !winnerMessage || !loserMessage) {
        return;
    }

    gameOverImage.src = "./gameover.png";

    // Falls nichts übergeben wird, zeig Standardtext
    winnerMessage.textContent = winnerText || "";
    loserMessage.textContent = loserText || "";

    screen.style.display = "flex";
}

function gameLoop() {
    if (gameOver) return; // Spiel sofort stoppen, wenn es vorbei ist
    requestAnimationFrame(gameLoop);
    updateGame();
}

function restartGame() {
    location.reload(); // Lädt die Seite neu
}

// Fügt ein Event zum Neustart hinzu
document.addEventListener("keydown", (event) => {
    if (gameOver && event.key === "r") {
        restartGame();
    }
});

function gameInterval(fun, time) {
    let interval = setInterval(fun, time);
    GAMELOOPJS_INTERVALS.push(interval);
    return interval;
}

function endGame() {
    gameOver = true;
    stopMapMovement();
    
    let winner, loser;

    if (chickenLives > catLives) {
        winner = chicken.name;
        loser = cat.name;
    } else {
        winner = cat.name;
        loser = chicken.name;
    }

    const winnerTextElement = document.getElementById('winner-text');
    const loserTextElement = document.getElementById('loser-text');
    
    if (winnerTextElement && loserTextElement) {
        winnerTextElement.innerText = `🏆 Gewinner: ${winner}`;
        loserTextElement.innerText = `💀 Verlierer: ${loser}`;
    } 

    const gameOverImage = document.getElementById("gameOverImage");
    if (gameOverImage) {
        gameOverImage.src = "./gameover.png"; // Bildpfad anpassen
    }

    const gameOverScreen = document.getElementById('game-over-screen');
    if (gameOverScreen) {
        gameOverScreen.style.display = 'flex';
    }
}

let combo = [];
  const easterSequence = ['k', 'a', 't', 'z', 'e', 'n', 'l', 'e', 'b', 'e', 'n'];

  document.addEventListener('keydown', (e) => {
    combo.push(e.key.toLowerCase());
    if (combo.length > easterSequence.length) combo.shift();

    if (combo.join('') === easterSequence.join('')) {
      triggerEasterEgg();
    }
  });
  
  function triggerEasterEgg() {
    // Musik abspielen mit Autoplay-Handling
    const music = document.getElementById('easterMusic');
    music.volume = 1;
    music.muted = false;
    music.play().catch(err => {
      console.warn('Musik konnte nicht abgespielt werden:', err);
    });
  
    // Startscreen-Element holen
    const startScreen = document.getElementById('start-screen');
  
    // Hintergrund schwarz machen
    startScreen.style.backgroundColor = 'black';
  
    // Optional: Bild abdunkeln
    const titleImage = document.querySelector('.title-image');
    if (titleImage) {
      titleImage.style.filter = 'brightness(0.2)';
    }
  
    // Buttons abdunkeln
    const buttons = document.querySelectorAll('.start-btn, .howto-btn');
    buttons.forEach(button => {
      button.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
      button.style.color = '#666';
      button.style.border = '1px solid #444';
      button.style.opacity = '0.1';
      button.style.pointerEvents = 'none';
    });
  
    // Hintergrund-Name einblenden
    const nameBanner = document.createElement('div');
    nameBanner.innerText = '🐔 Powered by Ümit & Fabian 🐱';
    nameBanner.style.position = 'absolute';
    nameBanner.style.top = '30%';
    nameBanner.style.left = '50%';
    nameBanner.style.transform = 'translateX(-50%)';
    nameBanner.style.color = 'yellow';
    nameBanner.style.fontSize = '40px';
    nameBanner.style.fontFamily = "'Doto', cursive";
    nameBanner.style.zIndex = 999;
    nameBanner.style.textShadow = '0 0 10px yellow, 0 0 20px orange, 0 0 30px red';
    startScreen.appendChild(nameBanner);
  
    const additionalText = document.createElement('div');
    additionalText.innerText = '🎉 RPK MARBURG 🎉';
    additionalText.style.position = 'absolute';
    additionalText.style.top = '38%';
    additionalText.style.left = '50%';
    additionalText.style.transform = 'translateX(-50%)';
    additionalText.style.color = 'white';
    additionalText.style.fontSize = '40px';
    additionalText.style.fontFamily = "'Doto', cursive";
    additionalText.style.zIndex = 999;
    additionalText.style.textShadow = '0 0 10px red, 0 0 20px red, 0 0 30px red';
    startScreen.appendChild(additionalText);
  
    // Animationen: Chicken & Cat
    const chicken = document.createElement('img');
    chicken.src = './img/Chicken/chickenlaufen7.png';
    chicken.classList.add('easter-chicken');
    startScreen.appendChild(chicken);
  
    const cat = document.createElement('img');
    cat.src = './img/Cat/cat7.png';
    cat.classList.add('easter-cat');
    startScreen.appendChild(cat);
  }  