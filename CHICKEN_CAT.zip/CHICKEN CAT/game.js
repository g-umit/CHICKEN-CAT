// Bildschirmbreite ermitteln
const screenWidth = window.innerWidth;  

addMap('./img/Hintergrund.jpg', 50);
moveMap(3);

let chicken = new GameObject('./img/Chicken/chickenlaufen0.png', 280, 426, 120, 'Chicken');
console.log(chicken.name);
chicken.animate(0, 6);
document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowUp') {
      chicken.jump(); // Falls der Charakter "chicken" springen soll
  }
});

let cat = new GameObject('./img/Cat/cat1.png', 80, 443, 105, 'Cat');
console.log(cat.name);
cat.animate(1, 4);

// Initialisieren der Leben für Chicken und Cat
let chickenLives = 9;
let catLives = 9;
let obstacles = []; // Array zur Speicherung der Hindernisse
const maxObstacles = 2; // Maximale Anzahl an Hindernissen

let lastObstacleX = 0; // Speichert die X-Position des letzten Hindernisses
const minObstacleDistance = 800; // Mindestabstand zwischen Hindernissen
const obstacleTypes = [  
    './img/hindernisse/Straßensperrung.png',  
    './img/hindernisse/Kegel.png' // Neues Hindernis hinzufügen
];

function addObstacle() {
  if (gameOver) return;
  if (obstacles.length >= maxObstacles) {
      let removedObstacle = obstacles.shift();
      if (removedObstacle) {
          removedObstacle.remove(); 
      }
  }

  let newX;
  do {
      newX = 1500 + Math.random() * 1500; // Zufällige Position
  } while (Math.abs(newX - lastObstacleX) < minObstacleDistance); // Sicherstellen, dass der Abstand groß genug ist

  lastObstacleX = newX; // Aktualisiert die letzte Hindernis-Position

  let randomObstacle = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)]; // Zufällig ein Hindernis auswählen

  let newObstacle = placeObstacle(randomObstacle, newX, 470, 100, 100);
  obstacles.push(newObstacle);
}

// Setzt ein Intervall für das regelmäßige Erzeugen von Hindernissen
setInterval(addObstacle, 5000);

// Funktion, um den Lebensbalken für das Huhn zu aktualisieren
function updateChickenLife() {
  if (gameOver) return;
  const lifeBar = document.getElementById('chickenLifeBar');
  const percentage = (chickenLives / 9) * 100; // Berechnung der Lebensprozente
  lifeBar.style.width = percentage + '%'; // Setzt die Breite des Lebensbalkens
}

// Funktion, um den Lebensbalken für die Katze zu aktualisieren
function updateCatLife() {
  if (gameOver) return;
  const lifeBar = document.getElementById('catLifeBar');
  const percentage = (catLives / 9) * 100; // Berechnung der Lebensprozente
  lifeBar.style.width = percentage + '%'; // Setzt die Breite des Lebensbalkens
}

// Beispiel für die Schadenfunktion (Kollision mit einem Hindernis)
function loseLife(character) {
  if (gameOver) return;
  if (character === 'chicken' && chickenLives > 0) {
    chickenLives--;
    updateChickenLife();
    if (chickenLives <= 0) {
      console.log("Das Huhn ist tot! Spiel vorbei!");
      endGame();
    }
  } else if (character === 'cat' && catLives > 0) {
    catLives--;
    updateCatLife();
    if (catLives <= 0) {
      console.log("Die Katze ist tot! Spiel vorbei!");
      endGame();
    }
  }
}

// Funktion zum Stoppen der Kartenbewegung
function stopMapMovement() {
  GAMELOOPJS_INTERVALS.forEach(interval => clearInterval(interval)); // Stoppt alle Intervalle
  GAMELOOPJS_INTERVALS = []; // Leert die Liste der Intervalle
}

// Funktion für die Kollisionserkennung, z.B. mit einem Hindernis
function checkCollisionWithObstacle(character) {
    // Wenn das Huhn oder die Katze mit einem Hindernis kollidiert
    // Dann rufen wir loseLife() auf
    if (character === 'chicken') {
      loseLife('chicken');
    } else if (character === 'cat') {
      loseLife('cat');
    }
  }

// Beispiel, wie die Kollision geprüft und Leben abgezogen werden
function isCollidingWithObstacle(object, obstacle) {
    // Hier prüfen wir, ob eine Kollision zwischen dem Objekt (z.B. Chicken oder Cat) und einem Hindernis besteht
    if (isColliding(object, obstacle)) {
      // Wenn ja, dann wird Leben abgezogen
      if (object === chicken) {
        loseLife('chicken');
      } else if (object === cat) {
        loseLife('cat');
      }
    }
  }

// Funktion für das Huhn nach links bewegen
function leftKeyPressed() {
    if (!gameOver) {
        // Überprüfen, ob das Huhn nicht links aus dem Bildschirm herausgeht
        if (chicken.x > 0) {
            chicken.x -= 22;
            chicken.imgElement.style.left = chicken.x + 'px';
        }
    }
}

// Funktion für das Huhn nach rechts bewegen
function rightKeyPressed() {
    if (!gameOver) {
        // Überprüfen, ob das Huhn nicht rechts aus dem Bildschirm herausgeht
        if (chicken.x + chicken.imgElement.width < screenWidth) {
            chicken.x += 30;
            chicken.imgElement.style.left = chicken.x + 'px';
        }
    }
}

// Funktion für das Huhn nach oben bewegen (springen)
function upKeyPressed() {
  if (!gameOver && !chicken.isJumping) {
      chicken.jump(295, 8);
  }
}

// Funktion für die Katze nach links bewegen
function aKeyPressed() {
    if (!gameOver) {
        // Überprüfen, ob die Katze nicht links aus dem Bildschirm herausgeht
        if (cat.x > 0) {
            cat.x -= 22;
            cat.imgElement.style.left = cat.x + 'px';
        }
    }
}

// Funktion für die Katze nach rechts bewegen
function dKeyPressed() {
    if (!gameOver) {
        // Überprüfen, ob die Katze nicht rechts aus dem Bildschirm herausgeht
        if (cat.x + cat.imgElement.width < screenWidth) {
            cat.x += 30;
            cat.imgElement.style.left = cat.x + 'px';
        }
    }
}

// Funktion für die Katze nach oben bewegen (springen)
function wKeyPressed() {
    if (!gameOver && !cat.isJumping) {
        cat.jump(295, 8);
    }
}